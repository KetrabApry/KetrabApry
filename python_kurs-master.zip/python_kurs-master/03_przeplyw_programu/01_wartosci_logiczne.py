# -*- coding: utf-8 -*-

val_1 = True
val_2 = False

# %%
print(val_1)
print(type(val_1))

# %% koniunkcja
True and True
True and False
False and True
False and False

# %% alternatywa
True or True
True or False
False or True
False or False

# %% negacja
True
not True
False
not False

# %%
bool('')
bool('0.0')
bool({})
bool(set())
bool(list())
bool(tuple())

bool({'key':'val'})












