# -*- coding: utf-8 -*-

# %%
imie = input('Podaj swoje imie: ')

# print('Czesc', imie)
print('Czesc {}!'.format(imie))

# %%
jezyk = input('Jakiego języka chcesz się nauczyć? ')

print('Podano język {}'.format(jezyk))

# %%
name = input('Podaj imie: ')
age = input('Podaj wiek: ')

print('Czesc {}! Masz {} lat.'.format(name, age))

# %%
age = int(input('Podaj wiek: '))
