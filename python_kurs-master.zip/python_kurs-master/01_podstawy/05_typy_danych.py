# -*- coding: utf-8 -*-

string = 'Python'

print(dir(string))

# %%
a = 10
print(dir(a))

# %%
type(a)
type(string)

# %%
b = 4.5
type(b)

# %%
d = 3 + 3j
type(d)

# %%
type(True)

value = True
print(value)
