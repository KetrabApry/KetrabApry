# -*- coding: utf-8 -*-

imie = 'Pawel'
_imie = 'Olek'

imie_3 = 'Ala'

# %%
a = 8
b = 20

c = a * b
print(c)

# %%
przepracowane_godziny = 8
stawka_godzinowa = 20

dzienna_pensja = przepracowane_godziny * stawka_godzinowa
print(dzienna_pensja)

# %%
camelCase = 'Python 3.7'
PascalCase = 'Python 3.7'
snake_case = 'Python 3.7'
kebab-case = 'Python 3.7'
UPPER = 'Python'

# %%
import keyword
keyword.kwlist