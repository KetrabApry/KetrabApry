# -*- coding: utf-8 -*-

name = 'Python'

# %%
# print(name[0])
print(name[-2])
print(name[::-1])

# %%
# name[start:stop]
# name[:stop]
# name[start:]
# name[start:stop:step]
name[1:4]
name[:4]
name[2:]

name[:]

# %%
name[-3:]
name[-3:-1]

# %%
full = 'Python Programming'
print(full[7:])
print(full[::2])

# %%
sample = '#stop#this#flow'
print(sample[::5])

# %%
numbers = '8,9,7,4'
print(numbers[::2])

# %%
print(numbers[::-1])

# %%
name = 'kajak'
print(name[::-2])
# %%

name = 'Python'

'Py' in name
'java' in name









