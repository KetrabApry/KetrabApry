# -*- coding: utf-8 -*-

def add(a, b):
    """Zwraca sumę dwóch liczb.

    Inputs:
        a: int
        b: int

    Outputs:
        sum: int"""
    return a + b

# %%
help(add)