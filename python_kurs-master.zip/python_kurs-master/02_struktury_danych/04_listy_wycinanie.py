# -*- coding: utf-8 -*-

# %%

index = [ 0,  1,  2,  3,  4,  5]
idx_n = [-6, -5, -4, -3, -2, -1]

lista = [34, 23, 56, 24, 23, 76]

# %%

# lista[start:stop]
# lista[index]
# lista[start:]
# lista[:stop]
# lista[::step]

lista[0]
lista[1]
lista[-1]
lista[-3]

# %%
lista[1:5]
lista[-5:-1]
lista[::-1]

# %%
lista[:4]
lista[3:]