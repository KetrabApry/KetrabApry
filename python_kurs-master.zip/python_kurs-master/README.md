# python kurs

Repozytorium jest częścią kursu [Programowanie w języku Python - od A do Z](https://www.udemy.com/programowanie-w-jezyku-python/?couponCode=BONUSCODE) dostępnego na platformie Udemy.com
