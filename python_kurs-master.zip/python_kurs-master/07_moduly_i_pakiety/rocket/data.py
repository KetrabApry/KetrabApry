# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 21:23:52 2019

@author: krako
"""

def get_data():
    return [1, 2, 3, 4, 5, 6]