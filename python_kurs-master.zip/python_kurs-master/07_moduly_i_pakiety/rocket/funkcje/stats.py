# -*- coding: utf-8 -*-

def mean(x):
    return sum(x) / len(x)

