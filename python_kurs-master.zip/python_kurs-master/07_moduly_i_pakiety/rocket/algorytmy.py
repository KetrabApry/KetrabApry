# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 21:24:30 2019

@author: krako
"""

def drzewa_decyzyjne():
    print('Algorytm drzew decyzyjnych.')

def sieci_neuronowe():
    print('Sieci neuronowe.')
