# -*- coding: utf-8 -*-

import rocket_science

# %%
dir(rocket_science)

# %%
rocket_science.calculate_mean([3, 4])
rocket_science.calculate_min([3, 4])
rocket_science.calculate_max([3, 4])

# %%

from rocket_science import calculate_mean

# %%
calculate_mean([2, 3])

# %%
from rocket_science import *

# %%
calculate_mean([4, 2])

# %%
from rocket_science import calculate_min, calculate_max

# %%
calculate_min([4, 5])
calculate_max([4, 5])