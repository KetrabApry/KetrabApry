# -*- coding: utf-8 -*-

def calculate_mean(x):
    return sum(x) / len(x)

def calculate_min(x):
    return min(x)

def calculate_max(x):
    return max(x)