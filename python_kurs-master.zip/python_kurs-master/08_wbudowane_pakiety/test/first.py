# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 18:35:27 2019

@author: krako
"""

print('Nazwa modułu: ', __name__)

if __name__ == '__main__':
    print('Uruchamiamy bezporednio')
else:
    print('Uruchamiamy z importu')