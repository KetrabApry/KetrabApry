# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 18:35:36 2019

@author: krako
"""

import first

print('Nazwa drugiego modułu:', __name__)